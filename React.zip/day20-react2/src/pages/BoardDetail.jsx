

export default function BoardDetail() {
  return (
    <div>BoardDetail</div>
  )
}
