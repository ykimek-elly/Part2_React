import "./SassEx1.scss"

export default function SassEx1() {
  return (
    <div>
        <h2>Scss?</h2>


        <div className="box">
          <h3>안녕! scss!</h3>
          <p>스타일이 더 깔끔해졌어요!</p>

        </div>



        <br /><br /><br /><br /><br /><br />
        <ul>
            <li>css를 더 똑똑하게 쓸 수 있는 디자인 확장 언어!</li>
            <li>같은 코드가 반복되는 구조, 복잡해지는 경우가 있다.</li>
            <li>변수,함수등 사용할 수 있다 유지보수 훨씬 쉽다!</li>
            <li>확장자.scss</li>
        </ul>
    </div>
  )
}
