import React from 'react'

export default function ScssEx1() {
  return (
    <div>
        <h2>중첩 -css안에 css또 작성!</h2>
        <div className='card'>
            <img src="" alt="" />
            <h3>Scss Card</h3>
            <p>중첩 스타일 적용!</p>
        </div>
    </div>
  )
}
