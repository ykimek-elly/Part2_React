import React from 'react'
import ChartEx from '../component/chart/ChartEx'

export default function ChartPage() {
  return (
    <div>
        <ChartEx />
    </div>
  )
}
