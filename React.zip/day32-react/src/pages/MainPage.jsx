import React from 'react'
import SassEx1 from '../component/sassEx/SassEx1'
import ScssEx from '../component/sassEx/ScssEx1'
import ScssEx1 from '../component/sassEx/ScssEx1'
import ScssEx2 from '../component/sassEx/ScssEx2'
import ScssEx3 from '../component/ScssEx3'
import ScssEx실습 from '../component/ScssEx실습'

export default function MainPage() {

  return (
    <div>
        {/* <h3>메인페이지</h3> */}
        {/* <SassEx1 /> */}
        {/* <ScssEx1 /> */}
        {/* <ScssEx2 /> */}
        {/* <ScssEx3 /> */}
        <ScssEx실습 />
    </div>
  )
}
