
import ModuleScssEx from '../component/ModuleScssEx/ModuleScssEx'

export default function ModuleScssPage() {
  return (
    <div>
      <ModuleScssEx />

    </div>
  )
}

