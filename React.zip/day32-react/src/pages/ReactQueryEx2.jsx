// ReactQueryEx2.jsx

import { useQueries, useQuery, useQueryClient } from "@tanstack/react-query"
import axios from "axios";

// 현재 예제는 여러 API를 동시에 관리할 때 
// 각각의 API마다 다른 queryKey를 주면 완벽하게 분리해서
// 기억(캐시) 할수있는 예제!
// 한 쇼핑몰에서 user,product,commnets 댓글 

// 새로고침 
//  - 주기적으로 업데이트 한 내용들을 가져올 수있다. 



export default function ReactQueryEx2() {

    // 1. 먼저 관리하는 useQuery들을 만든다.

    // 사용자에 대한 정보
    const {data : users ,
      isLoading : userIsLoading,
        isError : userIsError
    } = useQuery({
        queryKey : ["users"],
        queryFn :  () => axios
                            .get("https://dummyjson.com/users?limit=5")
                            .then((res) => res.data.users)
        
    });
    // 물건에 대한 정보
    const {data : products ,
      isLoading : productsIsLoading, 
        isError : productsIsError
    } = useQuery({
        queryKey : ["products"],
        queryFn: () => axios
                      .get("https://dummyjson.com/products?limit=5").then((res) => res.data.products),

    });
    // 댓글목록 
    const {data : comments,
       isLoading: commentsIsLoding,
        isError : commentsIsError
    } = useQuery({
        queryKey : ["comments"],
        queryFn: () => axios
                      .get("https://dummyjson.com/comments?limit=5").then((res) => res.data.comments),
    })

    // 구조 분해는 배열이나 객체 안의 값을 꺼내서 변수로 바로 사용할 수있는
    // 문법 
    const results = useQueries({
        queries : [
            {queryKey : ["users"]},
            {queryKey : ["products"]},
            {queryKey : ["comments"]}
        ]
    })
    

    const [userQuery, productQuery, cocmmentQuery] = results;

    console.log("로딩:",userQuery.isLoading);
 /*
    queryCache:
    ├─ ["users"]    → 사용자 목록 캐시
    ├─ ["products"] → 상품 목록 캐시
    └─ ["comments"] → 댓글 목록 캐시
 */
  //로딩 상태
  if(userIsLoading     ||
     productsIsLoading ||
     commentsIsLoding  ){
        return <p>데이터 가져오는 중!...</p>
  }

  // 에러 상태 
  if (userIsError     ||
      productsIsError ||
      commentsIsError  ){
        
        return <p>💥 데이터 요청 중 오류가 발생했습니다!</p>
   }

  // const queryClient = useQueryClient();

  // const handleRefresh = ()=>{
  //   // products 
  //   //  캐시 무효화 +  자동 요청 
  //   queryClient.invalidateQueries(["products"]);
  // }

  /*
  실행순서!
  사용자 클릭 → invalidateQueries(["products"])
              ↓
  ["products"] 캐시 상태 = stale(오래됨)
              ↓
  React Query: “새로 불러와야겠다!”
              ↓
  queryFn (axios 요청) 다시 실행
              ↓
  최신 데이터 수신 → 화면 자동 업데이트

  실제 실무에서의 패턴
   상품 등록 -> 수정 -> 삭제후  최신목록으로 자동 갱신
   댓글 작성후  새로운 댓글 즉시 반영
  */

  return (
    <div>
      <h3>API 여러개 호출 (React Query)</h3>
      {/* <button onClick={handleRefresh}>새로고침</button> */}
      
      {/* 👩 사용자 */}
      <section>
        <h4>👩 사용자 목록</h4>
        <ul>
            {users.map((u) => 
                <li key={u.id}>{u.username}</li>
            )}
        </ul>
      </section>

      {/* 🛒 상품 */}
      <section>
        <h4>🛒 상품 목록</h4>
        <ul>{products.map((p) => <li key={p.id}>{p.title}</li>)}</ul>
      </section>

      {/* 💬 댓글 */}
      <section>
        <h4>💬 댓글 목록</h4>
        <ul>{comments.map((c) => <li key={c.id}>{c.body}</li>)}</ul>
      </section>
    </div>
  )
}

/*
 useQuery 의 실행 순서
 ┌──────────────────────────────────────────┐
 │          ReactQueryEx2 컴포넌트 실행          │
 └──────────────────────────────────────────┘
                      │
                      ▼
        ┌────────────────────────────┐
        │  useQuery() 3개 등록 (동시 실행) │
        └────────────────────────────┘
            │           │           │
            │           │           │
            ▼           ▼           ▼
 ┌────────────────┐ ┌────────────────┐ ┌────────────────┐
 │ useQuery(["users"]) │ │ useQuery(["products"]) │ │ useQuery(["comments"]) │
 └────────────────┘ └────────────────┘ └────────────────┘
      │                     │                     │
      │ (queryFn 실행)       │ (queryFn 실행)       │ (queryFn 실행)
      ▼                     ▼                     ▼
 ┌────────────────┐ ┌────────────────┐ ┌────────────────┐
 │ axios 요청 전송      │ │ axios 요청 전송      │ │ axios 요청 전송      │
 └────────────────┘ └────────────────┘ └────────────────┘
      │                     │                     │
      ▼                     ▼                     ▼
 ┌────────────────┐ ┌────────────────┐ ┌────────────────┐
 │ 응답 수신 완료       │ │ 응답 수신 완료       │ │ 응답 수신 완료       │
 └────────────────┘ └────────────────┘ └────────────────┘
      │                     │                     │
      ▼                     ▼                     ▼
 ┌────────────────┐ ┌────────────────┐ ┌────────────────┐
 │ 캐시 저장: ["users"] │ │ 캐시 저장: ["products"] │ │ 캐시 저장: ["comments"] │
 └────────────────┘ └────────────────┘ └────────────────┘
      │                     │                     │
      ▼                     ▼                     ▼
 ┌──────────────────────────────────────────┐
 │      React Query 자동 상태 업데이트         │
 │      (isLoading → false, data 채워짐)      │
 └──────────────────────────────────────────┘
                      │
                      ▼
 ┌──────────────────────────────────────────┐
 │         컴포넌트 자동 리렌더링(화면다시그리기!) 발생│
 │   users, products, comments 데이터 표시     │
 └──────────────────────────────────────────┘
                      │
                      ▼
 ┌──────────────────────────────────────────┐
 │  QueryCache 유지 (5분간 재요청 없음)        │
 │  동일 queryKey 요청 시 캐시 즉시 반환       │
 └──────────────────────────────────────────┘


*/