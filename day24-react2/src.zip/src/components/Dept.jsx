import React from 'react'

export default function Dept({dept}) {
  return (
    <div>
        <h4>당신의 부서 : {dept}</h4>
    </div>
  )
}
