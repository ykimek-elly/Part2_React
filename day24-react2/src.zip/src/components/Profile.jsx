import React from 'react'
import UserName from './UserName';

export default function Profile() {
    const usename = "Seohee";
  return (
    <div>
        <UserName username={username}/>
    </div>
  )
}
