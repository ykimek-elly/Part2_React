import React from 'react'
import { MyContext } from '../MyContext'

export default function Test1() {
    
    let {useName} = useContext(MyContext);
    // console.log(result);
  
    return (
    <div>
        <h3> Test1 컴포넌트가 userName 가져오기</h3>
        <p>이름: {useName} </p>
    </div>
  )
}
