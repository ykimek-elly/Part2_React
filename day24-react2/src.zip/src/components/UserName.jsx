import React from 'react'
import JobCom from './JobCom';

export default function UserName({username}) {
    const job = "풀스택 개발자";
  return (
    <div>
        <h4>이름: {username}</h4>
        <JobCom job={job}/>
    </div>
  )
}
