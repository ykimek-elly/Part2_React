import React from 'react'
import Profile from '../components/Profile'

export default function MainPage() {
  return (
    <div className='container mt-4'>
        <h2>props 지옥</h2>
        <Profile />
    </div>
  )
}
